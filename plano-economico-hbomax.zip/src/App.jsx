import React, { useState } from 'react'

export default function App() {
  const [user, setUser] = useState(null)
  const [loginData, setLoginData] = useState({ email: '', password: '' })

  const handleLogin = () => {
    if (loginData.email && loginData.password) {
      const role = loginData.email.includes('prof') ? 'professor' : 'aluno'
      setUser({ name: loginData.email.split('@')[0], role })
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black via-neutral-900 to-black flex items-center justify-center text-white p-4">
        <div className="bg-neutral-900/80 backdrop-blur-md rounded-lg p-6 w-full max-w-sm shadow-lg">
          <h2 className="text-2xl font-bold mb-4">Entrar — Plano Econômico</h2>
          <input
            className="w-full mb-3 p-2 rounded bg-neutral-800 border border-neutral-700"
            placeholder="E-mail"
            value={loginData.email}
            onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
          />
          <input
            className="w-full mb-4 p-2 rounded bg-neutral-800 border border-neutral-700"
            type="password"
            placeholder="Senha"
            value={loginData.password}
            onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
          />
          <button
            className="w-full bg-pink-600 hover:bg-pink-500 transition py-2 rounded font-semibold"
            onClick={handleLogin}
          >
            Entrar
          </button>
          <p className="text-sm text-neutral-400 mt-3">Dica: use um e-mail contendo 'prof' para logar como professor.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-gradient-to-r from-purple-800 to-indigo-900 p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="px-3 py-1 bg-gradient-to-r from-pink-500 to-purple-600 rounded font-bold">PLANO ECONÔMICO</div>
          <nav className="hidden md:flex gap-4 text-sm opacity-90">
            <button className="hover:underline">Início</button>
            <button className="hover:underline">Temas</button>
            <button className="hover:underline">Quizzes</button>
            <button className="hover:underline">Simulações</button>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          {user.role === 'professor' && <div className="text-sm bg-yellow-500 text-black px-2 py-1 rounded">Professor</div>}
          <div className="text-sm opacity-90">Olá, {user.name}</div>
          <button
            className="bg-neutral-800 px-3 py-1 rounded"
            onClick={() => setUser(null)}
          >
            Sair
          </button>
        </div>
      </header>

      <main className="p-6">
        <section className="mb-8">
          <div className="relative rounded-lg overflow-hidden bg-gradient-to-r from-neutral-800 via-neutral-900 to-black p-6 flex flex-col md:flex-row items-center gap-6">
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold">Aprenda, pratique e debata — estilo streaming</h1>
              <p className="mt-2 text-neutral-300 max-w-xl">Coleções de temas, quizzes interativos e atividades com visual inspirado em plataformas de streaming (fundo escuro, cards e carrossel).</p>
              <div className="mt-4 flex gap-3">
                <button className="bg-pink-600 px-4 py-2 rounded-md font-semibold shadow-md">Começar</button>
                <button className="bg-neutral-800 px-4 py-2 rounded-md">Explorar Temas</button>
              </div>
            </div>

            <div className="w-full md:w-1/3">
              <div className="grid grid-cols-2 gap-3">
                {['Selic','Inflação','Câmbio','Fiscal','PIB'].map((t) => (
                  <div key={t} className="bg-neutral-800 p-3 rounded-md hover:scale-105 transition-transform cursor-pointer">
                    <div className="h-28 rounded-md bg-gradient-to-br from-neutral-700 to-neutral-600 flex items-end p-3">
                      <div>
                        <div className="font-semibold">{t}</div>
                        <div className="text-xs text-neutral-300">Explorar {t}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <section className="lg:col-span-2 space-y-6">
            <div className="bg-neutral-800 p-4 rounded-lg">
              <h2 className="text-2xl font-semibold">Atividades em destaque</h2>
              <p className="text-neutral-300 mt-2">Quiz rápido e simulações para sala de aula.</p>
            </div>

            <div className="bg-neutral-800 p-4 rounded-lg">
              <h3 className="font-semibold">Feed da Turma</h3>
              <div className="mt-3 text-sm text-neutral-300">Comentários, dúvidas e compartilhamentos de atividades.</div>
            </div>

            <div className="bg-neutral-800 p-4 rounded-lg">
              <h3 className="font-semibold">Simulação Rápida</h3>
              <p className="text-neutral-300 mt-2 text-sm">Escolha uma política e observe efeitos hipotéticos em indicadores (simulação educativa).</p>
              <div className="mt-3 flex gap-3">
                <select className="bg-neutral-900 border border-neutral-800 px-3 py-2 rounded">
                  <option>Reduzir Selic em 1 p.p.</option>
                  <option>Aumentar gasto público 2%</option>
                  <option>Subir alíquota de impostos</option>
                </select>
                <button className="bg-purple-600 px-4 py-2 rounded">Rodar</button>
              </div>
            </div>
          </section>

          <aside>
            <div className="space-y-4">
              <div className="bg-neutral-800 p-4 rounded-lg">
                <h4 className="font-semibold">Progresso</h4>
                <div className="mt-3 text-sm">Quizzes: <strong>2/5</strong></div>
                <div className="w-full bg-neutral-700 h-3 rounded-md mt-2 overflow-hidden">
                  <div className="h-3 bg-gradient-to-r from-green-500 to-teal-400" style={{ width: '40%' }}></div>
                </div>
              </div>

              <div className="bg-neutral-800 p-4 rounded-lg">
                <h4 className="font-semibold">Líderes</h4>
                <ol className="mt-2 text-sm list-decimal list-inside">
                  <li>Mariana — 92%</li>
                  <li>Lucas — 88%</li>
                  <li>João — 76%</li>
                </ol>
              </div>
            </div>
          </aside>
        </div>
      </main>

      <footer className="bg-neutral-950 text-neutral-400 text-center p-4 mt-6">
        <p>© 2025 Plano Econômico Educativo — estilo HBO.</p>
      </footer>
    </div>
  )
}
