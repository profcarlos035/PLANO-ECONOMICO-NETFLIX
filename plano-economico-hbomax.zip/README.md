# Plano Econômico — HBO-style (Vite + React + Tailwind)

## Como rodar

1. Instale dependências:
   ```bash
   npm install
   ```

2. Rode em modo de desenvolvimento:
   ```bash
   npm run dev
   ```

3. Abra o endereço mostrado no terminal (ex: http://localhost:5173).

## Observações
- Interface com visual escuro inspirado em plataformas de streaming (HBO Max).
- Login simulado: use um e-mail que contenha `prof` para entrar como professor.
- Projeto mínimo para testar localmente. Pode ser integrado a backend/autenticação real depois.
